<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Back to home</name>
   <tag></tag>
   <elementGuidId>e3a96127-8a08-4359-a3b4-d5229b9529b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.MuiTypography-root.MuiTypography-body1.css-f8grl2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div/div/div[3]/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>1fbfe038-eddc-486b-8ecc-5bb91fc3d326</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-body1 css-f8grl2</value>
      <webElementGuid>6322426a-572a-4c72-8112-95a2d31b0d4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Back to home</value>
      <webElementGuid>e1a3bfd2-ac53-4c21-a631-4bb804ba5285</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-k008qs&quot;]/div[@class=&quot;MuiBox-root css-1695q56&quot;]/div[@class=&quot;MuiBox-root css-zx4g27&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1xko3lp&quot;]/div[@class=&quot;MuiBox-root css-16gdgcu&quot;]/p[@class=&quot;MuiTypography-root MuiTypography-body1 css-f8grl2&quot;]</value>
      <webElementGuid>75e9e4ce-ee6c-4b0b-8d16-ce8434475dbe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div/div/div[3]/p</value>
      <webElementGuid>2ba2d9d7-a290-496f-b56a-50c10daead3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Receipt'])[1]/following::p[1]</value>
      <webElementGuid>8059d7e6-45cf-43be-bd55-e4972633e437</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Finish'])[1]/following::p[19]</value>
      <webElementGuid>26a36d5f-7291-4e7c-bb22-6728ed5ed64d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Now'])[1]/preceding::p[1]</value>
      <webElementGuid>8763b5b1-f654-4762-8984-c22ac8927bc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Now'])[2]/preceding::p[2]</value>
      <webElementGuid>595300b0-f6da-4d86-a71f-12a6920ee268</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Back to home']/parent::*</value>
      <webElementGuid>c09660d9-7fd0-42c2-a2e5-4ed98cbb3dfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div[3]/p</value>
      <webElementGuid>c6d82f81-30e6-41f8-9901-5f365db17712</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Back to home' or . = 'Back to home')]</value>
      <webElementGuid>e97605b1-f66c-442d-9ab3-57fc92a07b41</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
