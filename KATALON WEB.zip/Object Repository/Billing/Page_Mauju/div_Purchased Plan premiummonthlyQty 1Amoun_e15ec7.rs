<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Purchased Plan premiummonthlyQty 1Amoun_e15ec7</name>
   <tag></tag>
   <elementGuidId>e048386a-4b8c-40ca-bc10-1d45cbe98ca7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.css-0 > div.MuiBox-root.css-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2fbf342b-2ae0-44a4-a0ce-5a40b0035565</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-0</value>
      <webElementGuid>dedeabab-443c-4859-b139-a13c8c1513cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Purchased Plan premiummonthlyQty 1Amount $ 8.99Discount $ 0Total Billing $ 8.99E-Wallet​DANAOVOPhone Number+62​ShopeePayLinkajaConfirm &amp; Pay</value>
      <webElementGuid>45c7ff05-f243-40ac-83ef-d16012d0cd1b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-k008qs&quot;]/div[@class=&quot;MuiBox-root css-1695q56&quot;]/div[@class=&quot;MuiBox-root css-zx4g27&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]</value>
      <webElementGuid>d790259f-15a5-4b80-bd30-1318269bd1bc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div</value>
      <webElementGuid>ca92f337-d686-49f9-b464-fffef0986f8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Finish'])[1]/following::div[2]</value>
      <webElementGuid>06fb544a-0da0-4d81-9644-dd45e8b91f80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Process'])[1]/following::div[5]</value>
      <webElementGuid>60e58880-302c-4f53-9ae9-c866374576d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>e02ab956-1f52-4934-a244-43f946a60d32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Purchased Plan premiummonthlyQty 1Amount $ 8.99Discount $ 0Total Billing $ 8.99E-Wallet​DANAOVOPhone Number+62​ShopeePayLinkajaConfirm &amp; Pay' or . = 'Purchased Plan premiummonthlyQty 1Amount $ 8.99Discount $ 0Total Billing $ 8.99E-Wallet​DANAOVOPhone Number+62​ShopeePayLinkajaConfirm &amp; Pay')]</value>
      <webElementGuid>24cff549-1396-4fca-92f4-a615d1819fd3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
