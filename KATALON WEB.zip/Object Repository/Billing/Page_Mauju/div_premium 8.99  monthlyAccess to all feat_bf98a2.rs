<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_premium 8.99  monthlyAccess to all feat_bf98a2</name>
   <tag></tag>
   <elementGuidId>bb4e84cd-74ab-4024-94f0-d781e12b5838</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='scrollable-auto-tabpanel-0']/div/div/div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>913a963b-bb42-4884-85c2-81368b2a410d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-egajcf</value>
      <webElementGuid>0a0eb5d7-d642-4cf0-bceb-65335bb7911a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>premium$ 8.99 / monthlyAccess to all featuresUnlimited ClientDelegate Your Work To Up To 7 AdminsPayment RemindersRecurring BillingBuy Now</value>
      <webElementGuid>9e109ecc-e023-4cc0-bf4a-5c5fef96ca73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;scrollable-auto-tabpanel-0&quot;)/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1m3fm0q&quot;]/div[@class=&quot;MuiBox-root css-egajcf&quot;]</value>
      <webElementGuid>03fc9bf9-67b9-43a6-a095-867c7ed2fc24</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='scrollable-auto-tabpanel-0']/div/div/div[3]</value>
      <webElementGuid>090a714c-5f69-4eb9-930d-58a48438730b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy Now'])[2]/following::div[1]</value>
      <webElementGuid>d465fb59-b765-459a-8bf9-061d044f9183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy Now'])[1]/following::div[20]</value>
      <webElementGuid>103ba368-c173-41f1-832c-a057fb8fbe67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='WAHUDAAHYAR'])[2]/preceding::div[28]</value>
      <webElementGuid>f01c92e0-0852-4a52-807e-951bf9ee2658</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div/div/div[3]</value>
      <webElementGuid>cf5f4a2d-43db-4b88-ac9e-7149a882e4fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'premium$ 8.99 / monthlyAccess to all featuresUnlimited ClientDelegate Your Work To Up To 7 AdminsPayment RemindersRecurring BillingBuy Now' or . = 'premium$ 8.99 / monthlyAccess to all featuresUnlimited ClientDelegate Your Work To Up To 7 AdminsPayment RemindersRecurring BillingBuy Now')]</value>
      <webElementGuid>9c0f9b32-1096-4504-9b37-9af6c9361b8f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
