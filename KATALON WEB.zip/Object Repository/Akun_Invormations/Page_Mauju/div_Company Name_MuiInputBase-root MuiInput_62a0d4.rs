<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Company Name_MuiInputBase-root MuiInput_62a0d4</name>
   <tag></tag>
   <elementGuidId>ce061b4e-bb28-4a17-87b3-f4ff18361fd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/div[2]/div[2]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-12.MuiGrid-grid-sm-6.css-rpybyc > div.MuiFormControl-root.MuiTextField-root.css-kq7677 > div.MuiInputBase-root.MuiInput-root.MuiInputBase-colorPrimary.MuiInputBase-formControl.css-czymc7</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9ddeec5d-4e3b-4e80-8d26-f58cc84732ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiInputBase-root MuiInput-root MuiInputBase-colorPrimary MuiInputBase-formControl css-czymc7</value>
      <webElementGuid>567292d4-4343-4351-bdb2-ee6b2297c635</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;WizardStyle_pageContainer__3nVuo&quot;]/div[@class=&quot;MuiBox-root css-1vdicyi&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-outlined MuiPaper-rounded WizardStyle_paper__2ULbd css-1cy6rd&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container css-20nmm&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-8 css-3kox02&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-2 css-isbt42&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 css-rpybyc&quot;]/div[@class=&quot;MuiFormControl-root MuiTextField-root css-kq7677&quot;]/div[@class=&quot;MuiInputBase-root MuiInput-root MuiInputBase-colorPrimary MuiInputBase-formControl css-czymc7&quot;]</value>
      <webElementGuid>f7a768db-f157-4b37-b831-d0a8c9655678</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/div[2]/div[2]/div/div/div</value>
      <webElementGuid>e8459098-e9ea-4fec-83af-c95bbb65f69d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Name'])[1]/following::div[1]</value>
      <webElementGuid>a87da36b-9160-473c-bc20-659750d2916b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Address'])[1]/following::div[5]</value>
      <webElementGuid>483354b3-5435-453a-a426-84e539471d74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Zip Code'])[1]/preceding::div[1]</value>
      <webElementGuid>99b7cddd-4839-470e-a491-eabb1bdbb5d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Country'])[1]/preceding::div[3]</value>
      <webElementGuid>a98d3bfe-c775-4e70-93dc-997a854a3ff8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div[2]/div/div/div</value>
      <webElementGuid>2ed0eebe-edb8-4224-96f4-353e7532382c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
