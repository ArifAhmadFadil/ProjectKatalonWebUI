<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Coba Dropdown</name>
   <tag></tag>
   <elementGuidId>318ebd9a-6bc4-477c-b3e5-193b3c07eaa6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
