<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Hl PhoneAkuRp 56.000</name>
   <tag></tag>
   <elementGuidId>690d0c50-48ea-42ba-97ba-be1120178e48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Hl Phone']/parent::*</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5db1232e-bb60-4d45-896c-25cf9e16e963</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiCardContent-root css-gvy7tg</value>
      <webElementGuid>745f2b4e-4c17-4d24-95b0-7caf8419980e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hl PhoneAkuRp 56.000</value>
      <webElementGuid>9cbbbda0-ff75-446c-b315-76ed42870ebf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;notranslate&quot;]/body[1]/div[@class=&quot;MuiDialog-root MuiModal-root css-do8kke&quot;]/div[@class=&quot;MuiDialog-container MuiDialog-scrollPaper css-ekeie0&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation24 MuiDialog-paper MuiDialog-paperScrollPaper MuiDialog-paperWidthSm MuiDialog-paperFullWidth css-mbdu2s&quot;]/div[@class=&quot;MuiDialogContent-root css-1dvpuz0&quot;]/div[@class=&quot;MuiBox-root css-iz2wcc&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-19e0rwf&quot;]/div[@class=&quot;MuiCardContent-root css-gvy7tg&quot;]</value>
      <webElementGuid>6a1ec713-748a-49c2-a3b2-29cfd4ea550f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hl Phone']/parent::*</value>
      <webElementGuid>77d6e0fb-85f0-4384-8c4f-c448eec2e71e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[4]/div/div</value>
      <webElementGuid>65ddf415-7e53-4de9-9f83-b852e15ab835</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Hl PhoneAkuRp 56.000' or . = 'Hl PhoneAkuRp 56.000')]</value>
      <webElementGuid>20b6dfc7-a617-4c37-bcd7-f1c1f45da8dd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
